
LUZ PARA OS ESQUECIDOS – CAPÍTULO I: A SEMENTE DO VAZIO
Autor: João Carlos Nogueira dos Santos Margarido (Cajonosama)
Copyright © 2025 – Todos os direitos reservados.

-----------------------------------------------------
📚 DIREITOS DE AUTOR E PROPRIEDADE INTELECTUAL
-----------------------------------------------------

Esta obra, incluindo todos os textos, personagens, enredo e elementos simbólicos,
é propriedade intelectual exclusiva de João Carlos Nogueira dos Santos Margarido,
também conhecido como "Cajonosama".

Qualquer reprodução, modificação, distribuição ou utilização sem autorização escrita
do autor é estritamente proibida e sujeita a penalizações legais.

-----------------------------------------------------
✅ PERMITIDO:
-----------------------------------------------------
✔️ Ler e partilhar o link da obra original, sem alterações.
✔️ Citar pequenos trechos para fins educacionais, artísticos ou pessoais.
✔️ Divulgar com créditos ao autor (nome e contacto).

-----------------------------------------------------
❌ PROIBIDO:
-----------------------------------------------------
✖️ Copiar ou publicar o conteúdo como sendo da sua autoria.
✖️ Traduzir, modificar, adaptar ou criar obras derivadas.
✖️ Vender, lucrar ou incluir este conteúdo em produtos comerciais.

-----------------------------------------------------
🔐 LICENÇA CREATIVE COMMONS
-----------------------------------------------------

Esta obra está licenciada sob:

📄 CC BY-NC-ND 4.0 – Atribuição-NãoComercial-SemDerivações

🔗 Detalhes da Licença:
https://creativecommons.org/licenses/by-nc-nd/4.0/

✅ Pode partilhar com crédito.
❌ Não pode modificar.
❌ Não pode usar comercialmente.

-----------------------------------------------------
📨 CONTACTO OFICIAL
-----------------------------------------------------

Autor: João Carlos Nogueira dos Santos Margarido
Nome artístico: Cajonosama
E-mail: nosamacajo@gmail.com

-----------------------------------------------------
🛡️ AVISO LEGAL
-----------------------------------------------------

Qualquer infração destes termos poderá levar a ações legais ou remoção da obra em plataformas digitais.

Esta história é parte de um universo literário em construção que representa um legado espiritual, artístico e simbólico.

Obrigado por respeitar a alma desta criação.

– Cajonosama
